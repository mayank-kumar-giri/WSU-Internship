# import nltk
#
# fp = open('data.txt',"r+")
# fp.seek(0,0)
# raw = fp.read().splitlines(True)
# for i in range(len(raw)):
#     print(raw[i].split("-x-"))
# # fp.writelines(final)
# fp.close()

a = "dWAWDAWDAawdaw"
a.lower()