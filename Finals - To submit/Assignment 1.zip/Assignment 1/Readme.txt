For executing Task 1:
python <filename>

For executing Task 2 and 3:
1. Enter the respective folder.
2. For Linux and Mac---
    export FLASK_APP=flaskr
    export FLASK_ENV=development
    flask run

    For Windows CMD---
    set FLASK_APP=flaskr
    set FLASK_ENV=development
    flask run
